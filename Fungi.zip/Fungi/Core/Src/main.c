/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <string.h>
#include "i2c-lcd.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define AHT10_ADRESS 0x38 << 1
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;
I2C_HandleTypeDef hi2c2;
I2C_HandleTypeDef hi2c3;

TIM_HandleTypeDef htim3;

UART_HandleTypeDef huart6;

/* USER CODE BEGIN PV */

// Define global variable for backlight state
uint8_t backlight_state = 1;
uint8_t Rx_data[10];  //  creating a buffer of 10 bytes
uint8_t *letter;  //  creating a buffer of 10 bytes
uint8_t result;

uint8_t AHT10_RX_Data1[6];
uint8_t AHT10_RX_Data2[6];
uint32_t AHT10_ADC_Raw1;
uint32_t AHT10_ADC_Raw2;
float temp1 = 0;
float temp2;
float hum1;
float hum2;
uint8_t AHT10_TmpHum_Cmd = 0xAC;
uint8_t AHT10_Switcher = 255;

char int_to_str[20]; // For the LCD
int errCounter = 0; // For error messages
int errorCode = 0; // Error codes:

float tempSet = 23;
float humSet = 60;

int counter = 0;
int heaterEnable = 1;
int heater = 0;
int pump = 0;
int coolingFan = 0;
int LEDs = 1;
int heaterState = 0;
int pumpState = 0;
int coolingFanState = 0;
int LEDsState = 0;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_I2C1_Init(void);
static void MX_I2C2_Init(void);
static void MX_TIM3_Init(void);
static void MX_I2C3_Init(void);
static void MX_USART6_UART_Init(void);
/* USER CODE BEGIN PFP */
void lcd_UI(float temp, float hum);
void lcd_errMsg(int errorCode);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_I2C1_Init();
  MX_I2C2_Init();
  MX_TIM3_Init();
  MX_I2C3_Init();
  MX_USART6_UART_Init();
  /* USER CODE BEGIN 2 */
  HAL_TIM_Base_Start_IT(&htim3); // Start the timer for interrupts
  lcd_init();
  lcd_clear();
  lcd_UI(temp1, hum1);
  lcd_errMsg(errorCode);

  //UART
result =  HAL_UART_Receive_IT (&huart6, Rx_data, 10);


  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {

	   if (HAL_I2C_IsDeviceReady(&hi2c1, AHT10_ADRESS,1, 100) != HAL_OK) {
		   errorCode = 3;
		   heaterEnable = 0;
	   }
	   else if (errorCode == 3) {
		  errorCode = 0;
		  heaterEnable = 1;
	   }

	  	// Set GPIO parameters
	  	  // For temperature
	  	if (temp1-tempSet > 1) {
	  		heater = 0;
	  		coolingFan = 1;
	  	}
	  	else if (temp1-tempSet < 0.2) {
	  		heater = 1 & heaterEnable;
	  		coolingFan = 0;
	  	}
	  	else {
	  		heater = 0;
	  		coolingFan = 0;
	  	}
	  	  // For humidity
	  	if (humSet-hum1 > 10 && counter <50 && heaterEnable) {
	  		pump = 1;
	  	}
	  	else {
	  		pump = 0;
	  	}

	  	// Set GPIO state
	  	if (heater != heaterState) {
	  		HAL_GPIO_WritePin(GPIOC, heater_Pin, heater);
	  		heaterState = heater;
	  	}
	  	if (coolingFan != coolingFanState) {
	  		HAL_GPIO_WritePin(coolingFan_GPIO_Port, coolingFan_Pin, coolingFan);
	  		coolingFanState = coolingFan;
	  	}
	  	if (LEDs != LEDsState) {
	  	  	HAL_GPIO_WritePin(LEDs_GPIO_Port, LEDs_Pin, LEDs);
	  	  	LEDsState = LEDs;
	  	}
	  	if (pump != pumpState) {
	  	  	HAL_GPIO_WritePin(pump_GPIO_Port, pump_Pin, pump);
	  	  	pumpState = pump;
	  	}
	  	counter++;
	  	if (counter > 200)
	  		counter = 0;

	  	// Check for errors
	  	if (temp1-tempSet > 5 && errorCode != 3)
	  		errorCode = 1;
	  	else if (temp1-tempSet < -5 && errorCode != 3)
	  		errorCode = 2;
	  	else if (errorCode != 3) {
	  		errorCode = 0;
	  	}

	  	// Print on the LCD
	  	if (errorCode != 0) {
			if (errCounter > 20) {
			lcd_UI(temp1, hum1);
			errCounter--;
			}
			else if (errCounter == 20) {
			lcd_errMsg(errorCode);
			errCounter--;
			}
			else if (errCounter <= 0) {
				errCounter = 40;
			}
			else {
				errCounter--;
			}
	  	}
	  	else {
	  		lcd_UI(temp1, hum1);
	  	}
	  	HAL_Delay(100);
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE2);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 84;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.ClockSpeed = 100000;
  hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief I2C2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C2_Init(void)
{

  /* USER CODE BEGIN I2C2_Init 0 */

  /* USER CODE END I2C2_Init 0 */

  /* USER CODE BEGIN I2C2_Init 1 */

  /* USER CODE END I2C2_Init 1 */
  hi2c2.Instance = I2C2;
  hi2c2.Init.ClockSpeed = 100000;
  hi2c2.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c2.Init.OwnAddress1 = 0;
  hi2c2.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c2.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c2.Init.OwnAddress2 = 0;
  hi2c2.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c2.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C2_Init 2 */

  /* USER CODE END I2C2_Init 2 */

}

/**
  * @brief I2C3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C3_Init(void)
{

  /* USER CODE BEGIN I2C3_Init 0 */

  /* USER CODE END I2C3_Init 0 */

  /* USER CODE BEGIN I2C3_Init 1 */

  /* USER CODE END I2C3_Init 1 */
  hi2c3.Instance = I2C3;
  hi2c3.Init.ClockSpeed = 100000;
  hi2c3.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c3.Init.OwnAddress1 = 0;
  hi2c3.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c3.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c3.Init.OwnAddress2 = 0;
  hi2c3.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c3.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C3_Init 2 */

  /* USER CODE END I2C3_Init 2 */

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 8400;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 1000;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */

}

/**
  * @brief USART6 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART6_UART_Init(void)
{

  /* USER CODE BEGIN USART6_Init 0 */

  /* USER CODE END USART6_Init 0 */

  /* USER CODE BEGIN USART6_Init 1 */

  /* USER CODE END USART6_Init 1 */
  huart6.Instance = USART6;
  huart6.Init.BaudRate = 9600;
  huart6.Init.WordLength = UART_WORDLENGTH_8B;
  huart6.Init.StopBits = UART_STOPBITS_1;
  huart6.Init.Parity = UART_PARITY_NONE;
  huart6.Init.Mode = UART_MODE_TX_RX;
  huart6.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart6.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart6) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART6_Init 2 */

  /* USER CODE END USART6_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, heater_Pin|pump_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LEDs_GPIO_Port, LEDs_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(coolingFan_GPIO_Port, coolingFan_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : blueButton_Pin */
  GPIO_InitStruct.Pin = blueButton_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(blueButton_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : heater_Pin pump_Pin */
  GPIO_InitStruct.Pin = heater_Pin|pump_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pin : LEDs_Pin */
  GPIO_InitStruct.Pin = LEDs_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  HAL_GPIO_Init(LEDs_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : coolingFan_Pin */
  GPIO_InitStruct.Pin = coolingFan_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  HAL_GPIO_Init(coolingFan_GPIO_Port, &GPIO_InitStruct);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  	if(AHT10_Switcher) {
  	HAL_I2C_Master_Receive_IT(&hi2c2, AHT10_ADRESS, (uint8_t*)AHT10_RX_Data2, 6);
  	AHT10_ADC_Raw2 = (((uint32_t)AHT10_RX_Data2[3] & 15) << 16) | ((uint32_t)AHT10_RX_Data2[4] << 8) | AHT10_RX_Data2[5];
  	temp2 = (float)(AHT10_ADC_Raw2 * 200.00 / 1048576.00) - 50.00;
  	AHT10_ADC_Raw2 = ((uint32_t)AHT10_RX_Data2[1] << 12) | ((uint32_t)AHT10_RX_Data2[2] << 4) | (AHT10_RX_Data2[3] >> 4);
  	hum2 = (float)(AHT10_ADC_Raw2*100.00/1048576.00);
  	HAL_I2C_Master_Transmit_IT(&hi2c1, AHT10_ADRESS, &AHT10_TmpHum_Cmd, 1);
  	}
  	else {
  		HAL_I2C_Master_Receive_IT(&hi2c1, AHT10_ADRESS, (uint8_t*)AHT10_RX_Data1, 6);
  		/* Convert to Temperature in °C */
  		AHT10_ADC_Raw1 = (((uint32_t)AHT10_RX_Data1[3] & 15) << 16) | ((uint32_t)AHT10_RX_Data1[4] << 8) | AHT10_RX_Data1[5];
  		temp1 = (float)(AHT10_ADC_Raw1 * 200.00 / 1048576.00) - 50.00;
  		/* Convert to Relative Humidity in % */
  		AHT10_ADC_Raw1 = ((uint32_t)AHT10_RX_Data1[1] << 12) | ((uint32_t)AHT10_RX_Data1[2] << 4) | (AHT10_RX_Data1[3] >> 4);
  		hum1 = (float)(AHT10_ADC_Raw1*100.00/1048576.00);
  		HAL_I2C_Master_Transmit_IT(&hi2c2, AHT10_ADRESS, &AHT10_TmpHum_Cmd, 1);
  		}
  	/* Invert */
  	AHT10_Switcher = ~AHT10_Switcher;
}

void lcd_UI(float temp, float hum) {
//lcd_clear();
lcd_put_cur(0, 0);
lcd_send_string ("Temp. = ");
sprintf(int_to_str, "%d C    ", (int)temp);
lcd_send_string(int_to_str);
lcd_put_cur(1, 0);
lcd_send_string ("Humid.= ");
sprintf(int_to_str, "%d", (int)hum);
lcd_send_string(int_to_str);
lcd_send_string (" %    ");
}

void lcd_errMsg(int errorCode) {
	lcd_put_cur(0, 0);
	lcd_send_string ("!! ERROR:    !!");
	lcd_put_cur(1, 0);
	if (errorCode == 1) {
		lcd_send_string ("!! Too hot    !!");
	}
	else if (errorCode == 2) {
		lcd_send_string ("!! Too cold   !!");
	}
	else if (errorCode == 3) {
		lcd_send_string ("!! Sensor err !!");
	}
	else {
		lcd_send_string ("!! Unknown    !!");
	}
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
  result = HAL_UART_Receive_IT(&huart6, Rx_data, 10);

}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
